package SystemManager;

import java.util.*;

public interface PersonnelRepository {
        
    public void addPersonnel(Personnel p);
    
    public void removePersonnel(Personnel p);
    
    public void updateRepository(List<Personnel> pList);
    
    public Personnel getPersonnelByAttribute(String attribute_type,Object attribute_value);
    
    public List<Personnel> getPersonnelRepo();
}