package SystemManager;

import java.util.*;
import java.io.*;

import static java.lang.System.out;

public class SampleMain{
    
    Crypter sys_crypter = new CrypterSymmetricMech();
    
    SystemFileOps sys_file_ops = new SystemFileMech(sys_crypter);
    
    PersonnelRepository p_repo = new PersonnelRepo();
    
    PersonnelAuthRepository p_auth_repo = new PersonnelAuthRepo();
    
    Logger logs = new LoggerMech();
    
    
    
    public static void main(String[] args) throws Exception{
        
        out.println("\n\t\tMAIN DRIVER \n");
        
        List<Personnel> repo = new ArrayList<>();
        
        
        Personnel p1 = new Personnel("Jack Carter","SNR","08000001","10 Shelby Drive");
        Personnel p2 = new Personnel("Mary Po","JNR","08000002","11 Shelby Drive");
        Personnel p3 = new Personnel("Ben Philip","SNR","08000003","12 Shelby Drive");
        Personnel p4 = new Personnel("Curt Sean","JNR","08000004","13 Shelby Drive");


        repo.add(p1); repo.add(p2); repo.add(p3); repo.add(p4);
        
        Main m = new Main();
        
        
        //m.sys_file_ops.storePersonnelRepositoryData(repo);

        //List<Personnel> repo2 = m.sys_file_ops.loadPersonnelRepositoryData();
        
    }
}