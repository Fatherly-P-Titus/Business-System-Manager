package SystemManager;

import java.util.*;
import java.text.*;
import java.lang.*;

import java.security.*;
import javax.crypto.*;
import javax.security.*;
import java.io.*;
import java.io.Serializable;

import javax.crypto.spec.IvParameterSpec;

import static java.lang.System.out;


public class SecurityMech implements Serializable{
    
    private String plain_data;
    private byte[] cipher_data;
    
    private SecretKey key;
    private IvParameterSpec iv;
    
    private final String mech_file = "cipher_mech.txt"; //s_pass,ks_pass,iv
    private final String sec_mec_file = "ftp_security_mech.ser"; //this.SecurityMech Instance
    private final String personnel_auth_file = "personnel_auth.txt"; //[p_auth_pass, p_id]
    private final String personnel_file = "sys_personnels.txt"; // [ID, name, desig, phone, address]
    
    // Designated Personnel List
    private List<Personnel> designated_personnel;
    
    public SecurityMech()throws Exception{
        this.plain_data = "null";
        this.cipher_data = "".getBytes();
        
        this.designated_personnel = new ArrayList<Personnel>();
        
        this.key = this.generateKey();
        this.iv = this.generateIV();
        
        out.println("SECURITY MECH INITIALIZED !");
        out.println("\nKEY: "+this.key.toString());
        out.println("\nIV: "+this.iv.toString());
    }
    
    public byte[] getCipher(){
        return this.cipher_data;
    }
    
    public static SecretKey generateKey()throws NoSuchAlgorithmException{
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        
        kgen.init(128);
        return kgen.generateKey();
    }
    
    public static IvParameterSpec generateIV()throws Exception{
        byte[] iv = new byte[16];
        SecureRandom sr = new SecureRandom();
            sr.nextBytes(iv);
        return new IvParameterSpec(iv);
            
    }
    
    public byte[] encrypt(String plain_text,SecretKey key,IvParameterSpec iv) throws Exception{
        Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key,iv);
        this.cipher_data = cipher.doFinal(plain_text.getBytes());
        
        return cipher.doFinal(plain_text.getBytes());
        
    }
    
    public byte[] encrypt(String plain_text) throws Exception{
        
        Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,this.key,this.iv);
        byte[] cipher_text = cipher.doFinal(plain_text.getBytes());
        this.cipher_data = cipher_text;
        
        return cipher_text;
    }
    
    public static String decrypt(byte[] cipher_text,SecretKey key,IvParameterSpec iv)throws Exception{
        Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key, iv);
        byte[] plain_text = cipher.doFinal(cipher_text);
        
        return new String(plain_text);
    }
    
    public String decrypt()throws Exception{
        Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,this.key, this.iv);
        byte[] plain_text = cipher.doFinal(this.cipher_data);
        
        String pText = new String(plain_text);
        this.plain_data = pText;
        
        //this.saveCipherMech();
        
        return pText;
    }
    
    
    public void saveCipherMech(){
        //Save System_Pass, KeyStore_Pass, IV to cipher_mech file
        
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(this.mech_file));
            
            bw.write(String.format("%s-%s-0-%s",FB("22359".getBytes()),FB(this.key.toString().getBytes()),FB("John Doe".getBytes())));
            bw.flush();
            bw.close();
            
            out.println("SECURITY CIPHER MECH SAVED !");
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    private byte[] convertToBytes(String barr_str,String sep){
        
        String[] b_splt = barr_str.split(sep);
        
        byte[] b = new byte[b_splt.length];
        
        for(int i = 0; i < b_splt.length; i++){
            b[i] = Byte.parseByte(b_splt[i]);
        }
        
        return b;
    }
    
    //FB -> Format Bytes
    private String FB(byte[] b){
        String str = "";
        for(byte s: b){
            str += ""+s+",";
        }
        return str.substring(0,str.length()-1);
    }
    
    public void loadCipherMech(String u_pass){
        try{
            BufferedReader br = new BufferedReader(new FileReader(this.mech_file));
            // [S_KEY, KS_KEY, A_COUNT, U_NAME]
            
            String line = br.readLine();
            
            out.printf("\nLINE DATA: \n%s\n",line);
            
            String[] dta = line.split("-");
            out.println(String.format("%s",line.split("-").length));
            
            out.println("\nDTA0 => "+dta[0]);
            
            byte[] dta0 = convertToBytes(dta[0],",");
            String str = new String(dta0);
            
            out.printf("\n%s <==> %s\n",u_pass,str);
            
            if(u_pass.equals(str)){
                out.println("USER PASSCODE VALID !");
            }else{
                out.println("USER PASSCODE INVALID !");
            }
            
            br.close();
            
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    
    
    public void persistSecurityMech(){
        //Serialize this SecurityMech Instance
        try{
            FileOutputStream fos = new FileOutputStream(this.sec_mec_file);
            ObjectOutputStream ois = new ObjectOutputStream(fos);
            
            ois.writeObject(this);
            
            out.println("FTP SECURITY MECH PERSISTED !");
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    
    //// PERSONNEL AUTH HANDLING
    public void savePersonnelAuths(){
        try{
            
            BufferedWriter bw = new BufferedWriter(new FileWriter(this.personnel_auth_file));
            
            for(Personnel p: this.designated_personnel){
                bw.write(String.format("%s,%s\n",p.getAuth(),p.getID()));
            }
            
            bw.flush();
            bw.close();
            
            out.println("PERSONNEL AUTH PASSES SAVED !");
            
        }catch(Exception e){
                e.printStackTrace();
            }
    }
    
    //ADD/SAVE PERSONNEL TO DESIGNATED PERSONNEL LIST
    public void includeDesignatedPersonnel(Personnel p){
        if(p.getAuth() == ""){
            p.setAuth(this.generatePersonnelAuth());
        }
        this.designated_personnel.add(p);
    }
    
    //GENERATE PERSONNEL AUTH 
    private String generatePersonnelAuth(){
        String auth = "";
        
        try{
            for(int i = 0; i < 11; i++){
                auth += String.format("%s",(int)(Math.random()*9));
                    
            }
            auth = new String(this.encrypt(auth));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        out.println("GENERATED PERSONNEL AUTH: \n"+auth);
        
        return auth;
    }
    
    /// DISPLAY DESIGNATED PERSONNEL
    public void displayDesignatedList(){
        out.println("* DISPLAYING DESIGNATED PERSONNEL =>\n");
        for(Personnel p: this.designated_personnel){
            out.printf("\n• \t%s <==> %s\n%s\n",p.getID(),p.getID(),p.toString());
        }
    }
    
    
    public String toString(){
        return String.format("CIPHER TEXT:\n %s\n\nPLAIN TEXT:\n %s\n\n",this.cipher_data,this.plain_data);
    }
    
     
    
}





























