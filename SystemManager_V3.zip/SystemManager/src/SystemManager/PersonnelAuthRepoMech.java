package SystemManager;

public class PersonnelAuthRepoMech extends PersonnelAuthRepo{
    
    
    
}