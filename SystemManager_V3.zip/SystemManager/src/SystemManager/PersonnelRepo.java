package SystemManager;

import java.util.*;

public class PersonnelRepo implements PersonnelRepository{
    
    private List<Personnel> personnelRepository = new ArrayList<>();

    
    public void updateRepository(List<Personnel> personnel_list){
        //personnelRepository = personnel_list;
    }
    
    public void addPersonnel(Personnel p){
        if(!personnelRepository.contains(p)){
            personnelRepository.add(p);
        }
    }
    
    public void removePersonnel(Personnel p){
        
        List<Personnel>repo = new ArrayList<>();
        
        for(Personnel ps: personnelRepository){
            if(! ps.equals(p)){
                repo.add(ps);
            }
        }
        
        updateRepository(repo);
    }
    
    public Personnel getPersonnelByAttribute(String attr, Object value){
        Personnel match = null;
        
        for(Personnel p: personnelRepository){
            
            switch(attr){
                case "Name" : 
                if(p.getName() == value){
                   match = p; 
                }; break;
                case "Auth" :
                if(p.getAuth() == value){
                    match = p;
                }; break;
                case "ID" :
                if(p.getID() == value){
                    match = p;
                }
            }
            
        }
        return match;
    }
    
    public List<Personnel> getPersonnelRepo(){
        return this.personnelRepository;
    }
    
    public void setPersonnelRepository(List<Personnel> pList){
        this.personnelRepository = pList;
    }
    
}