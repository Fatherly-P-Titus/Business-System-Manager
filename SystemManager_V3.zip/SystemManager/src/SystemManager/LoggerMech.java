package SystemManager;

import java.util.*;
import java.util.Stack;

public class LoggerMech implements Logger{
    
    String source; //The source class logging
    
    //LOGS SHOULD BE STACK COLLECTION
    private Stack<Log> info_logs;
    private Stack<Log> warning_logs;
    private Stack<Log> error_logs;
    
    Stack<Log> all_logs = new Stack<>();
    
    public LoggerMech(){
        this.info_logs = new Stack<>();
        this.warning_logs = new Stack<>();
        this.error_logs = new Stack<>();
        
        this.source = "GENERAL";
        
        logINFO("LOGGER INITIALIZED !");
    }
    
    public LoggerMech(String source){
        this.info_logs = new Stack<>();
        this.warning_logs = new Stack<>();
        this.error_logs = new Stack<>();
        
        this.source = source;
        logINFO("LOGGER INITIALIZED !");
    }
    
    public void log(String msg){
        Log lg = new Log(msg,"INFO");
        all_logs.add(lg);
        info_logs.add(lg);
    }
    
    public void logINFO(String msg){
        Log lg = new Log(msg,"INFO");
        all_logs.add(lg);
        info_logs.add(lg);
    }
    
    public void logWARNING(String msg){
        Log lg = new Log(msg,"WARNING");
        all_logs.add(lg);
        warning_logs.add(lg);
    }
    
    public void logERROR(String msg){
        Log lg = new Log(msg,"ERROR");
        all_logs.add(lg);
        error_logs.add(lg);
    }
    
    
    
    public void saveInfoLogs(){
        
    }
    
    public void saveWarningLogs(){
        
    }
    
    public void saveErrorLogs(){
        
    }
    
    
    
    public List<Log> getRecentLogs(){
        //get last 6 logs (2 from each log db)
        List<Log> rcnt_logs = new ArrayList<>();
        Stack<Log> source_list = this.info_logs;
        int count = 0, lap = 1;
        
        for(int i = 1; i < 7; i++){
            rcnt_logs.add(source_list.pop());
            count += 1;
            
            if(count == 2){
                switch(lap){
                    case 2: source_list = warning_logs; break;
                    case 3: source_list = error_logs; break;
                }
                lap += 1;
                count = 0;
            }
        }
        return rcnt_logs;
    }
    
    
    public String report(){
        StringBuilder sb = new StringBuilder();
        
        sb.append(String.format("\n\t [LOG REPORTS FROM: %s]",this.source));
        
        for(Log lg: this.all_logs){
            sb.append(String.format("• %s",lg.toString()));
            sb.append("\n");
        } return sb.toString();
    }
    
}