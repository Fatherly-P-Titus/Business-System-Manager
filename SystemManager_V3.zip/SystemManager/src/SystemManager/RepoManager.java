package SystemManager;

import java.util.*;
import java.util.Scanner;
import static java.lang.System.out;

public class RepoManager {
    
    private SystemFileOps sfo;
    
    private Logger logger = new LoggerMech("REPO MANAGER");
    
    private List<Personnel> personnel_repo;
    private List<Personnel> HDNP; //Hidden
    private List<Personnel> auth_repo;
    private List<Log> logs_repo;
    
    
    boolean personnel_repo_updated;
    boolean auth_repo_updated;
    
    public RepoManager(SystemFileOps sfo){
        this.sfo = sfo;
        
        this.personnel_repo_updated = false;
        this.auth_repo_updated = false;
        
        this.personnel_repo = sfo.getPersonnelRepository();
        this.auth_repo = sfo.getAuthRepository();
        this.logs_repo = sfo.getLogsRepository();
        
        this.HDNP = new ArrayList<>();
        
        out.println("REPO SIZE: "+this.personnel_repo.size());

    }
    
    public int getRepoSize(){
        return this.personnel_repo.size();
    }
    
    public void storeSaveRepoUpdate(){
        logger.logINFO("Saving Repository Updates");

        out.println("\n Saving Repository Updates...");
        if(personnel_repo_updated){
            this.sfo.storePersonnelRepositoryData(this.personnel_repo);
            logger.logINFO("Personnel Repository Updates Stored");
            this.personnel_repo_updated = false;
        }
        if(auth_repo_updated){
            this.sfo.storePersonnelAuthRepositoryData(this.auth_repo);
            logger.logINFO("Personnel Auth Repository Stored");
            this.auth_repo_updated = false;
        }
    }
    
    
    //COMMANDS FOR PERSONNEL REPOSITORY
    
    public void appendPersonnelRepo(Personnel p){
        this.personnel_repo.add(p);
        this.personnel_repo_updated = true;
        logger.logINFO("New Personnel Added To Personnel Repo");
    }
    
    public void removeFromPersonnelRepo(Personnel p){
        if(this.personnel_repo.contains(p)){
            this.personnel_repo.remove(p);
            personnel_repo_updated = true;
            logger.logINFO("Personnel Removed From Personnel Repo");

        }
    }
    
    public void switchPersonnelHDN(Personnel p){
        for(Personnel pl: this.personnel_repo){
            if(pl.equals(p)){
                pl.setHDN(true);
                this.HDNP.add(pl);
                logger.logINFO("Switched Personnel HDN Status");
            }
        }
    }
    
    public void replacePersonnel(Personnel p, Personnel pr){
        List<Personnel> p_repo = new ArrayList<>();
        out.println("Replacing Personnel....\n");
        out.println("REPO SIZE: "+this.personnel_repo.size());

        for(Personnel pl: this.personnel_repo){
            if(pl.equals(p)){
                out.println("found Target Object\nReplacing...\n");
                p_repo.add(pr);
            }else{
                p_repo.add(pl);
            }
        } this.personnel_repo = p_repo;
        out.println("REPO SIZE: "+this.personnel_repo.size());
        this.personnel_repo_updated = true;
        logger.logINFO(String.format("Performed Replacement Operation On Personnel Repository"));

    }
    
    public List<Personnel> queryPersonnelRepo(String attribute, String value){
        List<Personnel> matches = new ArrayList<>();
        
        logger.logINFO(String.format("Querying Personnel Repo: [%s = '%s']l",attribute,value));
        
        for(Personnel p: this.personnel_repo){
            switch(attribute){
                case "name" : 
                if(p.getName() == value){
                    matches.add(p);
                } break;
                case "designation" :
                if(p.getDesignation() == value){
                    matches.add(p);
                }break;
                case "phone" :
                if(p.getPhone() == value){
                    matches.add(p);
                }break;
                case "address" :
                if(p.getAddress() == value){
                    matches.add(p);
                }break;
                case "gender" :
                if(p.getGender() == value){
                    matches.add(p);
                }break;
                case "age" :
                if(p.getAge() == value){
                    matches.add(p);
                }break;
            }
        }
        if(matches.size() > 0){
            logger.logINFO(String.format("\t- Query Matches Found: %s",matches.size()));
        }
        
        return matches;
    }
    
    
    public List<Personnel> queryPersonnelRepo(String value){
        List<Personnel> matches = new ArrayList<>();
        
        logger.logINFO(String.format("Querying Personnel Repo: ['%s']",value));
        
        for(Personnel p: this.personnel_repo){
            if((p.getName() == value) || 
                (p.getDesignation() == value) ||
                (p.getPhone() == value) ||
                (p.getAddress() == value) ||
                (p.getGender() == value) ||
                (p.getAge() == value)){
                    matches.add(p);
                } 
        }
        logger.logINFO(String.format("/t- Query Matches: %s",matches.size()));
        return matches;
    }
    
    
    public Personnel listSelectPersonnelRepo(){
        Personnel p = null;
        
        out.println("\n\t [PERSONNEL REPOSITORY LIST] \n");
        
        Map<String,Personnel> list = new HashMap<>();
        
        Scanner sc = new Scanner(System.in);
        
        int count = 1;
        for(Personnel ps: this.personnel_repo){
            if(!ps.getHDN()){
                out.println(String.format("%s) %s\n",count,ps.showString()));
                list.put(""+count,ps);
                count += 1;
            }
        }
        
        out.printf("\t SELECT PERSONNEL: ");
        String option = sc.next();
        out.println();
        sc = null;
        
        if(list.containsKey(option)){
            p = list.get(option);
        }
        return p;
    }
    
    public void listRecords(){
        out.println("\n\t [PERSONNEL REPOSITORY LIST] \n");
        
        out.println("REPO SIZE: "+this.personnel_repo.size());
        
        Map<String,Personnel> list = new HashMap<>();
        
        //Scanner sc = new Scanner(System.in);
        
        int count = 1;
        for(Personnel ps: this.personnel_repo){
            if(!ps.getHDN()){
                out.println(String.format("%s) %s\n",count,ps.showString()));
                list.put(""+count,ps);
                count += 1;
            }
        }
    }
    
    public Personnel editPersonnel(Personnel p,String attribute,String value){
        if(this.personnel_repo.contains(p)){
            switch(attribute){
                case "name" :
                p.setName(value); break;
                case "designation" :
                p.setDesignation(value); break;
                case "phone" :
                p.setPhone(value); break;
                case "address" :
                p.setAddress(value); break;
                case "gender" :
                p.setGender(value); break;
                case "age" :
                p.setAge(value); break;
            }
        }
        
        return p;
    }
    
    
    public String generatePersonnelAuth(){
        String auth = "";
        
        try{
            
            List<String> alphanum = new ArrayList<>();
            alphanum.add("A");alphanum.add("B");alphanum.add("C");alphanum.add("J");
            alphanum.add("Q");alphanum.add("Y");alphanum.add("W");alphanum.add("Z");
            
            for(int i = 0; i < 3; i++){
                int rnd = (int)(Math.random()*7);
                auth += alphanum.get(rnd);
            }
            
            for(int i = 0; i < 3; i++){
                auth += String.format("%s",(int)(Math.random()*9));
            }
            //auth = new String(this.crypter.encrypt(auth));
        }catch(Exception e){
            e.printStackTrace();
        }
        //out.println("GENERATED PERSONNEL AUTH: \n"+auth);
        logger.logINFO(String.format("Generated Personnel Auth: %s",auth));

        return auth;
    }
    
    
    /// COMMANDS FOR PERSONNEL AUTH REPOSITORY
    public void appendAuthRepo(Personnel p){
        this.auth_repo.add(p);
        this.auth_repo_updated = true;
        logger.logINFO("New Personnel Added To Auth Repo");
    }
    
    public void removeFromAuthRepo(Personnel p){
        if(this.auth_repo.contains(p)){
            this.auth_repo.remove(p);
            this.auth_repo_updated = true;
            logger.logINFO("Personnel Removed From Auth Repo");

        }
    }

    
    public void displayLogs(){
        this.logger.report();
    }
     
}