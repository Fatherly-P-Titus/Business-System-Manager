package SystemManager;

import static java.lang.System.out;

import java.util.Scanner;
import java.util.*;

class UserManagerView{
    
    RepoManager rpm;
    
    Scanner sc;
    SystemFileOps sys_file_ops;

    List<Personnel> repo;
    
    public UserManagerView(SystemFileOps sfo, RepoManager rpm){
        this.rpm = rpm;
        
        sc = new Scanner(System.in);
        this.sys_file_ops = sfo;//new SystemFileMech(new CrypterSymmetricMech());
    }
    
    public void handleCommand(String cmd,Personnel po){
        Personnel p = null;
        
        switch(cmd){
            case "1" : 
            p = this.createPersonnel(); 
            sys_file_ops.registerPersonnel(p);
            break;
            case "2" : p = this.editPersonnel(po); break;
        }
    }
    
    
    public Personnel assignPersonnelDesignation(Personnel p){
        out.println("\n\t [ASSIGNING PERSONNEL DESIGNATION]\n");
        
        out.println(String.format("\n•) %s\n",p.toString()));
        
        out.printf("ASSIGN AUTH DESIGNATION: \n1) ADMIN\n2) SNR\n3) JNR\n\t=> ");
        //Scanner sc = new Scanner(System.in);
        String auth = sc.next();
        sc = null;
        switch(auth){
            case "1" : 
            p.setDesignation("ADMIN");
            //Set Auth_Pass
            p.setAuth(rpm.generatePersonnelAuth());
            rpm.appendAuthRepo(p);
            break;
            case "2" :
            p.setDesignation("SNR");
            p.setAuth(rpm.generatePersonnelAuth());
            break;
            case "3" :
            p.setDesignation("JNR");
            break;
        }
        
        return p;
    }
    
    public Personnel createPersonnel(){
        Personnel p = null;
        
        out.printf("PERSONNEL NAME: ");
        String p_name = sc.nextLine();
        
        out.println();
        out.printf("PERSONNEL GENDER: ");
        String p_gender = sc.nextLine();
        
        out.println();
        out.printf("PERSONNEL AGE: ");
        String p_age = sc.nextLine();
        
        out.println();
        out.printf("PERSONNEL DESIGNATION: ");
        String p_desig = sc.nextLine();
        
        out.println();
        out.printf("PERSONNEL PHONE: ");
        String p_phone = sc.nextLine();
        
        out.println();
        out.printf("PERSONNEL ADDRESS: ");
        String p_address = sc.nextLine();
        
        out.println("\n\t CREATED NEW PERSONNEL ");
        
        p = new Personnel(p_name,p_gender,p_age,p_desig,p_phone,p_address);
        
        rpm.appendPersonnelRepo(p);
        
        return p;
    }
    
    public void deletePersonnel(Personnel p){
        
        out.println(String.format("\t SURE TO REMOVE PERSONNEL ?\n[%s]",p.showString()));
        //Scanner sc = new Scanner(System.in);
        String option = sc.next();
        sc = null;
        if((option == "YES") || (option == "yes") || (option == "y") || (option == "Y")){
            rpm.removeFromPersonnelRepo(p);
        }
        
    }
    
    public Personnel editPersonnel(Personnel po){
        out.println("\n1)EDIT NAME \n2) EDIT GENDER \n3) EDIT AGE \n4) EDIT PHONE \n5) EDIT ADDRESS \n\t => ");
        
        String e_option = sc.nextLine();
        String nw_val = "";
        
        Personnel p = po;//new Personnel(); 
        
        out.println("\t [EDITING OPERATION] \n\n");
        
        out.printf("INITIAL PERSONNEL DATA: \n%s\n\n",po.showString());
        
        switch(e_option){
         case "1" :
            out.printf("PROVIDE NAME: ");
            nw_val = sc.nextLine();
            out.println();
            p.setName(nw_val); break;
         case "2" :
            out.printf("PROVIDE GENDER: ");
            nw_val = sc.nextLine();
            out.println();
            p.setGender(nw_val); break;
         case "3" :
            out.printf("PROVIDE AGE: ");
            nw_val = sc.nextLine();
            out.println();
            p.setAge(nw_val); break;   
         case "4" :
            out.printf("PROVIDE PHONE: ");
            nw_val = sc.nextLine();
            out.println();
            p.setPhone(nw_val); break;
         case "5" :
            out.printf("PROVIDE ADDRESS: ");
            nw_val = sc.nextLine();
            out.println();
            p.setAddress(nw_val); break;
        }
        
        out.printf("MODIFIED PERSONNEL DATA: \n%s\n\n",p.toString());

        rpm.replacePersonnel(po,p);
        
        return p;
    }
    
    public void hidePersonnel(Personnel p){
        rpm.switchPersonnelHDN(p);
    }
    
}




public class AdminCentral {
    
    SystemFileOps sfo;
    RepoManager rpm;
    UserManagerView umv;
    
    public AdminCentral(RepoManager r){
        //!this.sfo = sfo;
        this.rpm = r;
        umv = new UserManagerView(sfo, rpm);
        
        out.println("\n\t [ADMIN CENTRAL INITIALIZED] \n");
        
        out.println("REPO SIZE: "+this.rpm.getRepoSize());

    }
    
    
    public void show(){
        
        Scanner user_input = new Scanner(System.in);
        String u_level_option = "", u_option = "", umv_option = "";
        
        while(u_option != "E"){
        out.print("\n1) USER MANAGEMENT\n2) ACCESS CONTROL & SECURITY\n3) DATA MANAGEMENT\n4) REPORTS & LOGS\n\t => ");
        
        u_level_option = user_input.next();
            out.println("REPO SIZE: "+this.rpm.getRepoSize());

            while(u_option != "E"){    
                //out.println("CHOOSE SUB-OPERATION: ");
                //u_option = user_input.next();
                
        switch(u_level_option){
            case "1" : 
            
            out.print("\n\t [USER MANAGEMENT OPERATIONS]\n\n1) REGISTER PERSONNEL\n2) EDIT PERSONNEL\n3) DELETE PERSONNEL\n4) ASSIGN ROLE/PERMISSION\n5) HIDE RECORD\n6) LIST RECORDS\n\t => ");
            umv_option = user_input.next();	
              
              switch(umv_option){
                  case "1" : umv.createPersonnel(); break;
                  case "2" : umv.editPersonnel(rpm.listSelectPersonnelRepo()); break;
                  case "3" : umv.deletePersonnel(rpm.listSelectPersonnelRepo()); break;
                  case "4" : umv.assignPersonnelDesignation(rpm.listSelectPersonnelRepo()); break;
                  case "5" : umv.hidePersonnel(rpm.listSelectPersonnelRepo()); break;
                  case "6" : umv.rpm.listRecords();
                  default : rpm.displayLogs(); break;
              }
            this.rpm.storeSaveRepoUpdate();    
            break;
            case "2" :
              out.println("\n\t [ACCESS & SECURITY OPERATIONS]\n\n1) REGISTER PERSONNEL\n2) EDIT PERSONNEL\n3) DELETE PERSONNEL\n4) ASSIGN ROLE/PERMISSION\n5) ENABLE / DISABLE ACCESS\n"); break;
            case "3" : 
               out.println("\n\t [DATA MANAGEMENT OPERATIONS]\n\n1) REGISTER PERSONNEL\n2) EDIT PERSONNEL\n3) DELETE PERSONNEL\n4) ASSIGN ROLE/PERMISSION\n5) ENABLE / DISABLE ACCESS\n"); break;
            case "4" : 
               out.println("\n\t [REPORTS & LOGS OPERATIONS]\n\n1) REGISTER PERSONNEL\n2) EDIT PERSONNEL\n3) DELETE PERSONNEL\n4) ASSIGN ROLE/PERMISSION\n5) ENABLE / DISABLE ACCESS\n"); break;
            default : rpm.displayLogs(); break;
        }
             
            }
        
        }
        
        /*
        To Edit/Delete a personnel, we first list out all registered personnels,
        2) select the personnel we wish to perform our operation on
        */
    }
    
}