package SystemManager;

import java.util.*;

public class PersonnelAuthRepo implements PersonnelAuthRepository{
    
    private Map<String,Personnel>designated_personnel = new HashMap<String,Personnel>();

    
    public void addDesignatedPersonnel(Personnel p){
        if(p.getAuth() == ""){
            p.setAuth(this.generatePersonnelAuth(p.getDesignation()));
        }
        
        designated_personnel.put(p.getAuth(),p);
    }
    
    public Personnel getPersonnelByAuth(String s){
        return designated_personnel.get(s);
    }
    
    public Personnel getPersonnelByID(String id){
        Personnel p = null;
        for(Personnel ps: designated_personnel.values()){
            if(ps.getID() == id)
                p = ps;
                return ps;
        } return p;
    }
    
    public List<Personnel> getAllDesignatedPersonnel(){
        List<Personnel> designated_list = new ArrayList<>();
        
        for(Personnel ps: designated_personnel.values()){
            designated_list.add(ps);
        } return designated_list;
    }
    
    public void setDesignatedPersonnelList(List<Personnel> pList){
        for(Personnel ps: pList){
            designated_personnel.put(ps.getAuth(),ps);
        }
    }
    
    
    private String generatePersonnelAuth(String personnel_type){
        String auth = "";
        
        int type_spec = (personnel_type == "Admin")? 11 : 9;
        
            for(int i = 0; i < type_spec; i++){
                auth += String.format("%s",(int)(Math.random()*9));
                    
            }
        //out.println("GENERATED PERSONNEL AUTH: \n"+auth);
        
        return auth;
    }
    
}