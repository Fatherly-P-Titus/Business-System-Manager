package SystemManager;

import java.util.*;


//TO HANDLE THE FILE I/O OPERATIONS OF THE SYSTEM
public interface SystemFileOps {
    
    public String personnel_ser_file = "";
    public String personnel_data_file = "sys_personnels.txt";
    
    public String personnel_auth_ser_file = "";
    public String personnel_auth_data_file = "personnels_auth.txt";
    
    
    public String db_data_file = "";
    public String security_config_file = "";
    
    public String crypter_ser_file = "";
    
    public String keystore1_file = "";
    public String keystore2_file = "";
    
    public String sys_logs_file = "system_logs.txt"; //STORE INFO, WARNING, ERROR LOGS
    public String sys_reports_file = "";
    
    
    //FILE OPERATIONS FOR PERSONNEL
    public void storePersonnelRepositoryData(List<Personnel> pdb); //Normal file storage
    public void persistPersonnelRepositoryData(List<Personnel> pdb); //Serialize
    
    public List<Personnel> loadPersonnelRepositoryData();
    public List<Personnel> depersistPersonnelRepositoryData(); //Deserialize
    
    public List<Personnel> getPersonnelRepository();
    public List<Personnel> getAuthRepository();
    public List<Log> getLogsRepository();
    
    
    
    public void registerPersonnel(Personnel p);
    
    
    //FILE OPERATIONS FOR PERSONNEL AUTH
    public void storePersonnelAuthRepositoryData(List<Personnel> padb); //Normal file storage
    public void persistPersonnelAuthRepositoryData(Map<String,Personnel> padb); //Serialize
    
    public Map<String,Personnel> loadPersonnelAuthRepositoryData();
    public Map<String,Personnel> depersistPersonnelAuthRepositoryData(); //Deserialize
    
    public Map<String,Personnel> getPersonnelAuthRepository();
    
    public void registerPersonnelAuth(Personnel p);

    
    //FILE OPERATIONS FOR LOGS
    public void storeLogsData(Stack<Log>...logs);
    public Stack<Log> getInfoLogs();
    public Stack<Log> getWarningLogs();
    public Stack<Log> getErrorLogs();
    
    public List<Log> loadAllLogs();
    
    
    /// CRYPTER MECH PERSIST/DEPERSIST
    public void persistCrypterKey();
    public void depersistCrypterKey();
    
    
}