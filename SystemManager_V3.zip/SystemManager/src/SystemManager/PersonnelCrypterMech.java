package SystemManager;

public class PersonnelCrypterMech {
    Crypter crypter;
    
    public PersonnelCrypterMech(Crypter crypter){
        this.crypter = crypter;
    }
    
    public Crypter getCrypter(){
        return this.crypter;
    }
    
    
    public byte[] encryptPersonnel(Personnel p){
        return crypter.encrypt(p.toString());
    } 
    
    public String decryptPersonnel(byte[] cipher_text){
        return this.crypter.decrypt(cipher_text);
    }
    
    
    
    public String bytesToString(byte[]bs){
        String byte_str = "";
        
        for(byte b: bs){
            byte_str += String.format("%s",b);
        } return byte_str;
    } 
    
    private byte[] stringToBytes(String str){
        byte[] bytes = new byte[str.length()];
        
        char[] str_arr = str.toCharArray();
        for(int i = 0; i < str_arr.length; i++){
            bytes[i] = (byte) str_arr[i];
        } return bytes;
    } 
    
} 