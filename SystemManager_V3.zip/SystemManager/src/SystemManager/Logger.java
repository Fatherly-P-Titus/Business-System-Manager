package SystemManager;

import java.util.*;

public interface Logger {
    
    public List<Log> recent_logs = new ArrayList<>();
    
    public void log(String msg);
    
    public void logINFO(String msg);
    
    public void logERROR(String err);
    
    public void logWARNING(String warn);
    
    public List<Log> getRecentLogs();
    
    public String report();
    
}