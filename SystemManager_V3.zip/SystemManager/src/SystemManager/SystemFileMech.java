package SystemManager;

import java.util.List;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.*;
import java.util.*;

import android.util.Base64;


import java.io.*;
import java.nio.*;

import static java.lang.System.out;

public class SystemFileMech implements SystemFileOps{
    
    private List<Personnel> personnel_repo;
    
    private List<Personnel> designated_repo;
    
    private Map<String,Personnel> personnel_auth_repo;
    
    private List<Log> sys_logs; 
    
    Logger logger;
    
    //
    private Crypter crypter;
    
    
    // CONSTRUCTOR
    public SystemFileMech(){
        personnel_repo = new ArrayList<>();
        this.designated_repo = new ArrayList<>();
        personnel_auth_repo = new HashMap<>();
        
        sys_logs = new ArrayList<>();
        
        this.crypter = null;
    }
    
    public SystemFileMech(Crypter crypter){
        personnel_repo = new ArrayList<>();
        designated_repo = new ArrayList<>();
        personnel_auth_repo = new HashMap<>();
        
        sys_logs = new ArrayList<>();
        
        this.crypter = crypter;
        
        logger = new LoggerMech();
        
        this.loadPersonnelRepositoryData();
        this.loadAllLogs();
    }
    
    
    /// SETTER METHODS
    
    public void setCrypter(Crypter crypter){
        this.crypter = crypter;
    }
    
    public void setPersonnelRepository(List<Personnel> pL){
        this.personnel_repo = pL;
    }
    
    public void setPersonnelAuthRepository(Map<String,Personnel> repo){
        this.personnel_auth_repo = repo;
    }
    
    public void setSystemLogs(List<Log> logs){
        this.sys_logs = logs;
    }
    
    public Map<String,Personnel> getPersonnelAuthRepository(){
        return this.personnel_auth_repo;
    }
    
    //GETTER METHODS
    public List<Personnel> getPersonnelRepository(){
        return this.personnel_repo;
    }
    
    public List<Personnel> getAuthRepository(){
        return this.designated_repo;
    }
    
    public List<Log> getLogsRepository(){
        return this.sys_logs;
    }
    
    
    
 //FILE OPERATIONS FOR PERSONNEL
    
    public void registerPersonnel(Personnel p){
        this.personnel_repo.add(p);
    }
    
    
    //ENCRYPT EACH OBJECT DATA BEFORE STORAGE
    public void storePersonnelRepositoryData(List<Personnel> pdb){
        //Normal file storage
        System.out.println("\n\tSAVING PERSONNEL REPOSITORY!\n");
        
        try (FileWriter fw = new FileWriter(personnel_data_file, false);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter pw = new PrintWriter(bw)) {
                 
                 String data = "";
                 String base64Data = "";
                 
                 for(Personnel p: pdb){
                     data = p.toString();
                     
                      byte[] encryptedData = crypter.encrypt(data);
                      base64Data = Base64.encodeToString(encryptedData,Base64.NO_WRAP);
                      pw.println(base64Data);
                     
                      //System.out.println("\nBaseData: "+data);
                 }
                 
                 bw.flush();
                 //bw.close();
                 pw.close();
                 logger.logINFO("PERSONNEL DATA STORAGE OPERATION COMPLETE");
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    
    
    public void persistPersonnelRepositoryData(List<Personnel> pdb){
        try{
            
            FileOutputStream fos = new FileOutputStream(personnel_ser_file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(pdb);
            
            fos.close();
            oos.close();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    } //Serialize
    
    
    //DECRYPT EACH LINE
    public List<Personnel> loadPersonnelRepositoryData(){
        
        System.out.println("\n\tLOADING REPOSITORY\n");
        
        //List<Personnel> repo = new ArrayList<>();
        //List<String> decryptedMessages = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(personnel_data_file))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    byte[] encryptedData = Base64.decode(line,Base64.NO_WRAP);
                    String decrypted = crypter.decrypt(encryptedData);
                    //decryptedMessages.add(decrypted);
                    
                    System.out.println("• DECRYPTED: \n\t"+decrypted);
                    
                    Personnel p = new Personnel(decrypted);
                    this.personnel_repo.add(p);
                }
            }br.close();
          logger.logINFO("LOADING PERSONNEL DATA OPERATION COMPLETE	");  
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
        return this.personnel_repo;//  = repo;
        //return repo;
    }
    
    public List<Personnel> depersistPersonnelRepositoryData(){
        
        List<Personnel>repo = new ArrayList<>();
        try{
            
            FileInputStream fis = new FileInputStream(personnel_ser_file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            repo = (ArrayList<Personnel>) ois.readObject();
            
            this.setPersonnelRepository(repo);
        }catch(IOException ioe){
            ioe.printStackTrace();
        }catch(ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
        return repo;
    } //Deserialize
    
    
    
      //FILE OPERATIONS FOR PERSONNEL AUTH
    
    public void registerPersonnelAuth(Personnel p){
        if(p.getAuth() == "NONE"){
            p.setAuth(this.generatePersonnelAuth());
        }
        this.personnel_auth_repo.put(p.getAuth(),p);
        this.designated_repo.add(p);
    }
    
    
    public void storePersonnelAuthRepositoryData(List<Personnel> padb){
        System.out.println("\n\tSAVING AUTH REPOSITORY!\n");
        
        try (FileWriter fw = new FileWriter(personnel_auth_data_file, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
                 
                 String data = "";
                 String base64Data = "";
                 
                 for(Personnel p: padb){    
                     data = String.format("%s-%s",p.getAuth(),p.toString());
                     
                      byte[] encryptedData = crypter.encrypt(data);
                      base64Data = Base64.encodeToString(encryptedData,Base64.NO_WRAP);
                      out.println(base64Data);
                     
                      //System.out.println("\n\nBaseData: \n"+data);
                 }
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    } //Normal file storage
    
    
    public void persistPersonnelAuthRepositoryData(Map<String,Personnel> padb){
        try{
            FileOutputStream fos = new FileOutputStream(personnel_auth_ser_file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this.personnel_auth_repo);
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    } //Serialize
    
     
    
    public Map<String,Personnel> loadPersonnelAuthRepositoryData(){
        Map<String,Personnel> repo = new HashMap<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(personnel_auth_data_file))) {
            String line;
            String[] dta;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    byte[] encryptedData = Base64.decode(line,Base64.NO_WRAP);
                    String decrypted = crypter.decrypt(encryptedData);
                    
                    dta = decrypted.split("-");
                    //decryptedMessages.add(decrypted);
                    
                    System.out.println("•) DECRYPTED: \n\t"+decrypted);
                    
                    Personnel p = new Personnel(dta[1]);
                    this.personnel_auth_repo.put(dta[0],p);
                }
            }
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
        return this.personnel_auth_repo;
    }
    
    public Map<String,Personnel> depersistPersonnelAuthRepositoryData(){
        Map<String,Personnel>repo = new HashMap<>();
        try{
            
            FileInputStream fis = new FileInputStream(personnel_auth_ser_file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            repo = (HashMap<String,Personnel>) ois.readObject();
            
            this.setPersonnelAuthRepository(repo);
        }catch(IOException ioe){
            ioe.printStackTrace();
        }catch(ClassNotFoundException cnfe){
            cnfe.printStackTrace();
        }
        return repo;
    } //Deserialize
    
    
    
     //FILE OPERATIONS FOR LOGS
    public void storeLogsData(Stack<Log>...logs){
        //Save all three logs 
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(sys_logs_file));
            
            for(Stack<Log> lgs: logs ){
                for(Log log: lgs){
                    bw.write(String.format("%s\n",log.toString()));
                }
            }
            
            bw.flush();
            bw.close();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    public List<Log> loadAllLogs(){
        List<Log> logs = new ArrayList<>();
        try{
            BufferedReader br = new BufferedReader(new FileReader(sys_logs_file));
            
            String line = br.readLine();
            Log l = null;
            
            while(line != null){
                l = new Log();
                l.setLog(line);
                
                logs.add(l);
            }
            
            this.setSystemLogs(logs);
            
            br.close();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
        return logs;
    }
    
    public Stack<Log> getInfoLogs(){
        Stack<Log> info_logs = new Stack<>();
        
        for(Log log: this.sys_logs){
            if(log.getSource() == "INFO"){
              info_logs.push(log);  
            }
        } return info_logs;
    }
    
    public Stack<Log> getWarningLogs(){
        Stack<Log> warn_logs = new Stack<>();
        
        for(Log log: this.sys_logs){
            if(log.getSource() == "WARNING"){
              warn_logs.push(log);  
            }
        } return warn_logs;
    }
    
    public Stack<Log> getErrorLogs(){
        Stack<Log> error_logs = new Stack<>();
        
        for(Log log: this.sys_logs){
            if(log.getSource() == "ERROR"){
              error_logs.push(log);  
            }
        } return error_logs;
    }
    
    
    ///CRYPTER MECH PERSISTER / DEPERSISTER LOGIC
    public void persistCrypterKey(){
        try{
            FileOutputStream fos = new FileOutputStream(crypter_ser_file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(this.crypter.getCrypterKey());
            
            oos.close();
            System.out.println("CRYPTER SECRET KEY PERSISTED !");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void depersistCrypterKey(){
        Object key;
        try{
            FileInputStream fis = new FileInputStream(crypter_ser_file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            key = ois.readObject();
            
            ois.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    //GENERATE PERSONNEL AUTH 
    private String generatePersonnelAuth(){
        String auth = "";
        
        try{
            
            List<String> alphanum = new ArrayList<>();
            alphanum.add("A");alphanum.add("B");alphanum.add("C");alphanum.add("J");
            alphanum.add("Q");alphanum.add("Y");alphanum.add("W");alphanum.add("Z");
            
            for(int i = 0; i < 3; i++){
                int rnd = (int)(Math.random()*7);
                auth += alphanum.get(rnd);
            }
            
            for(int i = 0; i < 3; i++){
                auth += String.format("%s",(int)(Math.random()*9));
            }
            //auth = new String(this.crypter.encrypt(auth));
        }catch(Exception e){
            e.printStackTrace();
        }
        //out.println("GENERATED PERSONNEL AUTH: \n"+auth);
        
        return auth;
    }
    
}