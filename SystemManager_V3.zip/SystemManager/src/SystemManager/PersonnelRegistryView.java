package SystemManager;

// 1) Encrypt Personnel data
// 2) Save encrypted personnel data
// 3) Store CrypterMech

public class PersonnelRegistryView {
    //For creating Personnel
    
    Personnel p;
    SystemFileOps sfo;
    Crypter crypter;
    
    //STORE ENCRYPTED PERSONNEL OBJECT
    //IV + ENCRYPTED DATA
    
}