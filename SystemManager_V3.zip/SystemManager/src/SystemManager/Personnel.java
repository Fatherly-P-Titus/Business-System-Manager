package SystemManager;

import java.io.Serializable;

public class Personnel implements Serializable {
    
    private String name;
    private String designation;
    private String age;
    private String gender;
    private String phone;
    private String address;
    
    private String ID;
    private String auth_pass;
    
    private boolean hdn_stat;
    /// CONSTRUCTORS
    public Personnel(){
        this.name = "John Doe";
        this.gender = "M";
        this.age = "35";
        this.phone = "080000000";
        this.address = "10 New Shelby Drive";
        this.designation = "JNR";
        
        this.generateID();
        this.auth_pass = "NONE";
        
        this.hdn_stat = false;
    }
    
    public Personnel(String n,String d,String p,String a){
        this.name = n;
        this.designation = d;
        this.phone = p;
        this.address = a;
        
        this.generateID();
        
        this.auth_pass = "NONE";
        
        this.hdn_stat = false;
    }
    
    public Personnel(String n,String g,String age,String d,String p,String a){
        this.name = n;
        this.designation = d;
        this.phone = p;
        this.address = a;
        this.gender = g;
        this.age = age;
        
        this.generateID();
        
        this.auth_pass = "NONE";
        
        this.hdn_stat = false;
    }
    
    //ID,name, gender, age, desig, phone, address, auth
    public Personnel(String csv){
        String[]dta = csv.split(",");
        
        this.name = dta[1];
        this.gender = dta[2];
        this.age = dta[3];
        this.designation = dta[4];
        this.phone = dta[5];
        this.address = dta[6];
        
        this.ID = dta[0];
        
        this.auth_pass = dta[7];
        this.hdn_stat = Boolean.parseBoolean(dta[8]);
    }

    
    /// GETTER METHODS
    public String getName (){
        return this.name;
    }
    
    public String getGender(){
        return this.gender;
    }
    
    public String getAge(){
        return this.age;
    }
    
    public String getDesignation (){
        return this.designation;
    }
    
    public String getPhone (){
        return this.phone;
    }
    
    public String getAddress (){
        return this.address;
    }
    
    public String getID (){
        return this.ID;
    }
    
    public String getAuth(){
        return this.auth_pass;
    }
    
    public boolean getHDN(){
        return hdn_stat;
    }
    
    /// SETTER MRTHODS
    public void setName(String nm){
        this.name = nm;
    }
    
    public void setGender(String gender){
        this.gender = gender;
    }
    
    public void setAge(String age){
        this.age = age;
    }
    
    public void setDesignation(String desig){
        this.designation = desig;
    }
    
    public void setPhone(String p){
        this.phone = p;
    }
    
    public void setAddress(String a){
        this.address = a;
    }
    
    public void setAuth(String auth){
        this.auth_pass = auth;
    }
    
    public void setID(String id){
        this.ID = id;
    }
    
    public void setHDN(boolean stat){
        this.hdn_stat = stat;
    }
    
    private void generateID(){
        String id = "";
        
        for(int i = 0; i < 9; i++){
            id += String.format("%s",(int)(Math.random()*9));
        }
        this.ID = id;
    }
    
    
    public String showString(){
        //the object String to be shown / displayed
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s",this.ID,this.name,this.gender,this.age,this.designation,this.phone,this.address,this.auth_pass);
    }
    
    @Override
    public String toString(){
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s",this.ID,this.name,this.gender,this.age,this.designation,this.phone,this.address,this.auth_pass,this.hdn_stat);
    }
    
    @Override
    public boolean equals(Object pobj){
        Personnel p = (Personnel) pobj;
        
        if((p.getName() == this.name) && (p.getID() == this.ID)){
          return true;   
        }else return false;
    }
    
}