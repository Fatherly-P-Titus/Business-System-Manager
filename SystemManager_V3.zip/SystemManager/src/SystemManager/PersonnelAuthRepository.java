package SystemManager;

import java.util.*;

public interface PersonnelAuthRepository {
    
        
    public void addDesignatedPersonnel(Personnel dp);
    
    public Personnel getPersonnelByAuth(String auth);
    
    public Personnel getPersonnelByID(String id);
    
    public List<Personnel> getAllDesignatedPersonnel();
    
    public void setDesignatedPersonnelList(List<Personnel> d_list);
    
    //public void setDesignatedPersonnel(Map<String,Personnel> pm);
}