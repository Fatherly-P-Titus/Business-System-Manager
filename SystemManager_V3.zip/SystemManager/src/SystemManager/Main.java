package SystemManager;


import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.ArrayList;
import java.util.*;
import java.util.List;

import static java.lang.System.out;

public class Main {
    Crypter sys_crypter;
    
    SystemFileOps sys_file_ops;
    
    RepoManager rpm;
    
    PersonnelRepository p_repo = new PersonnelRepo();
    
    PersonnelAuthRepository p_auth_repo = new PersonnelAuthRepo();
    
    Logger logs = new LoggerMech();
    
    public Main(){
        this.sys_crypter = new CrypterSymmetricMech();
        this.sys_file_ops = new SystemFileMech(this.sys_crypter);
        this.rpm = new RepoManager(this.sys_file_ops);
        
    }
    
    
    public static void main(String[] args) throws Exception{
        
        out.println("\n\t\tMAIN DRIVER \n");
        
        Main m = new Main();
        
        List<Personnel> repo = new ArrayList<>();
        List<Personnel> d_repo = new ArrayList<>();
        
        Map<String,Personnel> auth_repo = new HashMap<>();
        /*
        Personnel p1 = new Personnel("Jack Carter","M","32","SNR","08000001","10 Shelby Drive");
        m.sys_file_ops.registerPersonnelAuth(p1);
        Personnel p2 = new Personnel("Mary Po","F","26","JNR","08000002","11 Shelby Drive");
        Personnel p3 = new Personnel("Ben Philip","M","42","SNR","08000003","12 Shelby Drive");
        Personnel p4 = new Personnel("Curt Sean","M","28","JNR","08000004","13 Shelby Drive");
        m.sys_file_ops.registerPersonnelAuth(p4);
        

        repo.add(p1); repo.add(p2); repo.add(p3); repo.add(p4);
        d_repo.add(p1); d_repo.add(p4);
        */
        
        AdminCentral ac = new AdminCentral(m.rpm);
        
        //m.sys_file_ops.storePersonnelRepositoryData(repo);
           ////
        //m.sys_file_ops.storePersonnelAuthRepositoryData(d_repo);
        
       // out.println("\n\n");
        
        //List<Personnel> repo2 = m.sys_file_ops.loadPersonnelRepositoryData();
        
       // auth_repo = m.sys_file_ops.loadPersonnelAuthRepositoryData();
        
        //m.sys_crypter.storeKeyStore();
        out.println("\n==============================================\n");
        //m.sys_crypter.loadKeyStore();
        
        ac.show();
    }
}
